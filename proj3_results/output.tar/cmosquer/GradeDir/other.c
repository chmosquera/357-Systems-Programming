

int otherFunc()
{
   return 37;
}
